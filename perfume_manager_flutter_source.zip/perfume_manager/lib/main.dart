import 'dart:convert';
import 'dart:io';
import 'dart:math';

import 'package:csv/csv.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:intl/intl.dart';
import 'package:path/path.dart' as p;
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';
import 'package:share_plus/share_plus.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:sqflite/sqflite.dart';

const gold = Color(0xFFC6A15B);
const dark = Color(0xFF171512);
const cream = Color(0xFFF5F0E6);
final money = NumberFormat('#,##0.00', 'en');

String egp(num n) => '${money.format(n)} ج.م';
double numVal(String? s) => double.tryParse((s ?? '').trim().replaceAll(',', '.')) ?? 0;

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await AppDb.instance.database;
  runApp(const PerfumeApp());
}

class PerfumeApp extends StatelessWidget {
  const PerfumeApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false,
    title: 'إدارة عطور',
    locale: const Locale('ar'),
    theme: ThemeData(
      useMaterial3: true,
      fontFamily: 'Roboto',
      scaffoldBackgroundColor: cream,
      colorScheme: ColorScheme.fromSeed(seedColor: gold, brightness: Brightness.light,
        primary: const Color(0xFF6D5126), surface: Colors.white),
      appBarTheme: const AppBarTheme(backgroundColor: dark, foregroundColor: Colors.white,
        centerTitle: true, elevation: 0),
      cardTheme: CardThemeData(color: Colors.white, elevation: 1, margin: const EdgeInsets.all(6)),
      inputDecorationTheme: InputDecorationTheme(
        filled: true, fillColor: const Color(0xFFFAF8F3),
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none),
        contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 12)),
    ),
    builder: (context, child) => Directionality(textDirection: TextDirection.rtl, child: child!),
    home: const PinGate(),
  );
}

class AppDb {
  AppDb._();
  static final instance = AppDb._();
  Database? _db;

  Future<Database> get database async {
    if (_db != null) return _db!;
    final dir = await getDatabasesPath();
    _db = await openDatabase(p.join(dir, 'perfume_manager.db'), version: 1,
      onCreate: (db, version) async {
        await db.execute('''CREATE TABLE products(
          id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, type TEXT NOT NULL,
          brand TEXT, unit TEXT NOT NULL DEFAULT 'مل', buy REAL NOT NULL DEFAULT 0,
          sell REAL NOT NULL DEFAULT 0, qty REAL NOT NULL DEFAULT 0,
          alert_qty REAL NOT NULL DEFAULT 2, expiry TEXT, notes TEXT, created_at TEXT NOT NULL)''');
        await db.execute('''CREATE TABLE sales(
          id INTEGER PRIMARY KEY AUTOINCREMENT, invoice_no TEXT NOT NULL UNIQUE,
          customer TEXT, product_id INTEGER, product_name TEXT NOT NULL,
          qty REAL NOT NULL, unit_price REAL NOT NULL, unit_cost REAL NOT NULL,
          discount REAL NOT NULL DEFAULT 0, total REAL NOT NULL, paid REAL NOT NULL,
          payment TEXT NOT NULL, status TEXT NOT NULL, created_at TEXT NOT NULL)''');
        await db.execute('''CREATE TABLE expenses(
          id INTEGER PRIMARY KEY AUTOINCREMENT, category TEXT NOT NULL,
          amount REAL NOT NULL, payment TEXT NOT NULL, note TEXT, created_at TEXT NOT NULL)''');
        await db.execute('''CREATE TABLE stock_moves(
          id INTEGER PRIMARY KEY AUTOINCREMENT, product_id INTEGER, product_name TEXT,
          kind TEXT NOT NULL, qty REAL NOT NULL, note TEXT, created_at TEXT NOT NULL)''');
        await db.execute('''CREATE TABLE customers(
          id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, phone TEXT, address TEXT, notes TEXT)''');
        await db.execute('''CREATE TABLE suppliers(
          id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, phone TEXT, address TEXT, notes TEXT)''');
        await db.execute('''CREATE TABLE purchases(
          id INTEGER PRIMARY KEY AUTOINCREMENT, supplier TEXT, product_id INTEGER,
          product_name TEXT, qty REAL, unit_cost REAL, total REAL, paid REAL, created_at TEXT)''');
        await db.execute('''CREATE TABLE settings(key TEXT PRIMARY KEY, value TEXT)''');
      });
    return _db!;
  }

  Future<List<Map<String, Object?>>> rows(String table, {String? orderBy}) async =>
    (await database).query(table, orderBy: orderBy ?? 'id DESC');
  Future<int> add(String table, Map<String, Object?> values) async =>
    (await database).insert(table, values);
}

class PinGate extends StatefulWidget {
  const PinGate({super.key});
  @override State<PinGate> createState() => _PinGateState();
}
class _PinGateState extends State<PinGate> {
  final pin = TextEditingController();
  String? error;
  bool setup = false;
  @override void initState() { super.initState(); _check(); }
  Future<void> _check() async {
    final prefs = await SharedPreferences.getInstance();
    if (prefs.getString('pin') == null) setState(() => setup = true);
  }
  Future<void> _enter() async {
    final prefs = await SharedPreferences.getInstance();
    final saved = prefs.getString('pin');
    if (setup) {
      if (pin.text.length < 4) { setState(() => error = 'الرقم السري 4 أرقام على الأقل'); return; }
      await prefs.setString('pin', pin.text);
      if (!mounted) return;
      Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => const Home()));
    } else if (pin.text == saved) {
      if (!mounted) return;
      Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => const Home()));
    } else { setState(() => error = 'الرقم السري غير صحيح'); }
  }
  @override Widget build(BuildContext context) => Scaffold(
    backgroundColor: dark,
    body: Center(child: ConstrainedBox(constraints: const BoxConstraints(maxWidth: 360),
      child: Padding(padding: const EdgeInsets.all(24), child: Column(mainAxisSize: MainAxisSize.min, children: [
        const Icon(Icons.local_florist, color: gold, size: 64),
        const SizedBox(height: 12),
        const Text('إدارة عطور', style: TextStyle(color: Colors.white, fontSize: 28, fontWeight: FontWeight.bold)),
        const SizedBox(height: 8),
        Text(setup ? 'أنشئ رقمًا سريًا للدخول' : 'أدخل الرقم السري', style: const TextStyle(color: Colors.white70)),
        const SizedBox(height: 18),
        TextField(controller: pin, obscureText: true, keyboardType: TextInputType.number,
          inputFormatters: [FilteringTextInputFormatter.digitsOnly], style: const TextStyle(color: Colors.white),
          decoration: const InputDecoration(hintText: 'الرقم السري', hintStyle: TextStyle(color: Colors.white54))),
        if (error != null) Padding(padding: const EdgeInsets.all(8), child: Text(error!, style: const TextStyle(color: Colors.redAccent))),
        const SizedBox(height: 12),
        FilledButton(onPressed: _enter, child: Text(setup ? 'حفظ والدخول' : 'دخول')),
      ]))),
  );
}

class Home extends StatefulWidget {
  const Home({super.key});
  @override State<Home> createState() => _HomeState();
}
class _HomeState extends State<Home> {
  int index = 0;
  final pages = const [Dashboard(), ProductsPage(), SalesPage(), ExpensesPage(), ToolsPage()];
  final titles = const ['لوحة التحكم', 'المنتجات والمخزون', 'المبيعات والفواتير', 'المصاريف', 'أدوات وتقارير'];
  @override Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: Text(titles[index]), actions: [
      IconButton(tooltip: 'الإعدادات', onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const SettingsPage())), icon: const Icon(Icons.settings))
    ]),
    body: pages[index],
    bottomNavigationBar: NavigationBar(
      selectedIndex: index, onDestinationSelected: (v) => setState(() => index = v),
      destinations: const [
        NavigationDestination(icon: Icon(Icons.dashboard_outlined), label: 'الرئيسية'),
        NavigationDestination(icon: Icon(Icons.inventory_2_outlined), label: 'المنتجات'),
        NavigationDestination(icon: Icon(Icons.receipt_long), label: 'المبيعات'),
        NavigationDestination(icon: Icon(Icons.payments_outlined), label: 'المصاريف'),
        NavigationDestination(icon: Icon(Icons.calculate_outlined), label: 'أدوات'),
      ]),
  );
}

class Dashboard extends StatefulWidget {
  const Dashboard({super.key});
  @override State<Dashboard> createState() => _DashboardState();
}
class _DashboardState extends State<Dashboard> {
  Map<String, double> stats = {};
  List<Map<String,Object?>> low = [], latest = [];
  @override void initState() { super.initState(); load(); }
  Future<void> load() async {
    final db = await AppDb.instance.database;
    final now = DateTime.now();
    final start = DateTime(now.year, now.month, now.day).toIso8601String();
    final week = now.subtract(Duration(days: now.weekday - 1));
    final month = DateTime(now.year, now.month);
    final year = DateTime(now.year);
    Future<double> sum(String table, String col, String from) async {
      final r = await db.rawQuery('SELECT COALESCE(SUM($col),0) v FROM $table WHERE created_at >= ?', [from]);
      return (r.first['v'] as num).toDouble();
    }
    final salesToday = await sum('sales','total',start);
    final salesWeek = await sum('sales','total',week.toIso8601String().substring(0,10));
    final salesMonth = await sum('sales','total',month.toIso8601String());
    final salesYear = await sum('sales','total',year.toIso8601String());
    final exp = await sum('expenses','amount',year.toIso8601String());
    final cogs = await db.rawQuery('SELECT COALESCE(SUM(qty*unit_cost),0) v FROM sales WHERE created_at >= ?', [year.toIso8601String()]);
    final cost = (cogs.first['v'] as num).toDouble();
    final count = Sqflite.firstIntValue(await db.rawQuery('SELECT COUNT(*) FROM sales')) ?? 0;
    final lowRows = await db.rawQuery('SELECT * FROM products WHERE qty <= alert_qty ORDER BY qty ASC LIMIT 6');
    final latestRows = await db.query('sales', orderBy: 'id DESC', limit: 5);
    if (!mounted) return;
    setState(() {
      stats = {'today':salesToday,'week':salesWeek,'month':salesMonth,'year':salesYear,
        'expenses':exp,'profit':salesYear-cost-exp,'count':count.toDouble()};
      low = lowRows; latest = latestRows;
    });
  }
  Widget tile(String title, String value, IconData icon) => Card(child: Padding(padding: const EdgeInsets.all(14),
    child: Row(children: [CircleAvatar(backgroundColor: gold.withOpacity(.18), child: Icon(icon,color: dark)),
      const SizedBox(width: 10), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(title, style: const TextStyle(color: Colors.black54, fontSize: 12)),
        const SizedBox(height: 4), Text(value, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16))
      ]))])));
  @override Widget build(BuildContext context) => RefreshIndicator(onRefresh: load, child: ListView(padding: const EdgeInsets.all(10), children: [
    Container(padding: const EdgeInsets.all(18), decoration: BoxDecoration(color: dark,borderRadius: BorderRadius.circular(18)),
      child: const Row(children: [Icon(Icons.auto_awesome,color: gold,size: 36), SizedBox(width: 12),
        Expanded(child: Text('إدارة مشروعك… ببساطة واحترافية',style: TextStyle(color: Colors.white,fontSize: 18,fontWeight: FontWeight.bold)))])),
    const SizedBox(height: 8),
    GridView.count(crossAxisCount: 2, shrinkWrap: true, physics: const NeverScrollableScrollPhysics(), childAspectRatio: 1.8,
      children: [
        tile('مبيعات اليوم',egp(stats['today']??0),Icons.today),
        tile('مبيعات الأسبوع',egp(stats['week']??0),Icons.date_range),
        tile('مبيعات الشهر',egp(stats['month']??0),Icons.calendar_month),
        tile('مبيعات السنة',egp(stats['year']??0),Icons.trending_up),
        tile('مصروفات السنة',egp(stats['expenses']??0),Icons.money_off),
        tile('صافي ربح السنة*',egp(stats['profit']??0),Icons.account_balance_wallet),
        tile('عدد الفواتير','${stats['count']?.toInt()??0}',Icons.receipt),
      ]),
    const Padding(padding: EdgeInsets.all(8), child: Text('* صافي الربح = المبيعات - تكلفة البضاعة المباعة - المصروفات المسجلة',style: TextStyle(fontSize: 11,color: Colors.black54))),
    const SectionTitle('تنبيهات المخزون'),
    if (low.isEmpty) const EmptyHint('لا توجد منتجات وصلت لحد التنبيه')
    else ...low.map((e)=>ListTile(leading: const Icon(Icons.warning_amber,color: Colors.deepOrange),
      title: Text('${e['name']}'), subtitle: Text('المتاح: ${e['qty']} ${e['unit']} | حد التنبيه: ${e['alert_qty']}'))),
    const SectionTitle('أحدث الفواتير'),
    if (latest.isEmpty) const EmptyHint('لا توجد فواتير حتى الآن')
    else ...latest.map((e)=>ListTile(leading: const Icon(Icons.receipt_long,color: gold),
      title: Text('${e['invoice_no']} - ${e['product_name']}'),
      subtitle: Text('${e['created_at']} • ${e['status']}'), trailing: Text(egp((e['total'] as num).toDouble())))),
  ]));
}

class SectionTitle extends StatelessWidget {
  final String title; const SectionTitle(this.title,{super.key});
  @override Widget build(BuildContext context)=>Padding(padding: const EdgeInsets.fromLTRB(8,16,8,6),
    child: Text(title,style: const TextStyle(fontSize:17,fontWeight:FontWeight.bold,color:dark)));
}
class EmptyHint extends StatelessWidget {
  final String text; const EmptyHint(this.text,{super.key});
  @override Widget build(BuildContext context)=>Padding(padding: const EdgeInsets.all(18),child: Center(child: Text(text,style: const TextStyle(color:Colors.black45))));
}

class ProductsPage extends StatefulWidget {
  const ProductsPage({super.key});
  @override State<ProductsPage> createState()=>_ProductsPageState();
}
class _ProductsPageState extends State<ProductsPage> {
  List<Map<String,Object?>> items=[];
  String query='';
  @override void initState(){super.initState();load();}
  Future<void> load() async { final x=await AppDb.instance.rows('products'); if(mounted)setState(()=>items=x.where((e)=>'${e['name']}'.contains(query)).toList());}
  Future<void> edit([Map<String,Object?>? item]) async {
    final name=TextEditingController(text:'${item?['name']??''}');
    final brand=TextEditingController(text:'${item?['brand']??''}');
    final buy=TextEditingController(text:'${item?['buy']??''}');
    final sell=TextEditingController(text:'${item?['sell']??''}');
    final qty=TextEditingController(text:'${item?['qty']??'0'}');
    final alert=TextEditingController(text:'${item?['alert_qty']??'2'}');
    String type='${item?['type']??'غير ذلك'}';
    String unit='${item?['unit']??'مل'}';
    final types=['رجالي','نسائي','أطفال','زيوت عطرية','بخور','معطر','هدية','غير ذلك'];
    final units=['مل','جرام','كجم','لتر'];
    final ok=await showDialog<bool>(context:context,builder:(ctx)=>StatefulBuilder(builder:(ctx,setD)=>AlertDialog(
      title:Text(item==null?'إضافة منتج':'تعديل منتج'),
      content:SizedBox(width:400,child:SingleChildScrollView(child:Column(mainAxisSize:MainAxisSize.min,children:[
        _field(name,'اسم المنتج'), DropdownButtonFormField(value:type,decoration:const InputDecoration(labelText:'النوع'),items:types.map((e)=>DropdownMenuItem(value:e,child:Text(e))).toList(),onChanged:(v)=>setD(()=>type=v!)),
        _field(brand,'الماركة / المورد'), DropdownButtonFormField(value:unit,decoration:const InputDecoration(labelText:'الوحدة'),items:units.map((e)=>DropdownMenuItem(value:e,child:Text(e))).toList(),onChanged:(v)=>setD(()=>unit=v!)),
        _field(buy,'سعر الشراء',num:true),_field(sell,'سعر البيع',num:true),_field(qty,'الكمية',num:true),_field(alert,'حد التنبيه',num:true)
      ]))),
      actions:[TextButton(onPressed:()=>Navigator.pop(ctx,false),child:const Text('إلغاء')),FilledButton(onPressed:()=>Navigator.pop(ctx,true),child:const Text('حفظ'))]
    )));
    if(ok!=true||name.text.trim().isEmpty)return;
    final values={'name':name.text.trim(),'type':type,'brand':brand.text,'unit':unit,'buy':numVal(buy.text),'sell':numVal(sell.text),'qty':numVal(qty.text),'alert_qty':numVal(alert.text),'created_at':DateTime.now().toIso8601String()};
    final db=await AppDb.instance.database;
    if(item==null){final id=await db.insert('products',values);await db.insert('stock_moves',{'product_id':id,'product_name':name.text,'kind':'رصيد افتتاحي','qty':numVal(qty.text),'created_at':DateTime.now().toIso8601String()});}
    else {await db.update('products',values,where:'id=?',whereArgs:[item['id']]);}
    await load();
  }
  Future<void> stock(Map<String,Object?> item) async {
    final c=TextEditingController(); String kind='إضافة';
    final ok=await showDialog<bool>(context:context,builder:(ctx)=>StatefulBuilder(builder:(ctx,setD)=>AlertDialog(title:const Text('حركة مخزون'),
      content:Column(mainAxisSize:MainAxisSize.min,children:[DropdownButtonFormField(value:kind,items:['إضافة','تالف','فقد','هدية','استهلاك داخلي','تعديل'].map((e)=>DropdownMenuItem(value:e,child:Text(e))).toList(),onChanged:(v)=>setD(()=>kind=v!)),_field(c,'الكمية',num:true)]),
      actions:[TextButton(onPressed:()=>Navigator.pop(ctx,false),child:const Text('إلغاء')),FilledButton(onPressed:()=>Navigator.pop(ctx,true),child:const Text('تنفيذ'))])));
    final q=numVal(c.text); if(ok!=true||q<=0)return;
    final db=await AppDb.instance.database; final current=(item['qty'] as num).toDouble();
    final next=kind=='إضافة'?current+q:kind=='تعديل'?q:current-q;
    if(next<0){if(mounted)ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('الكمية غير كافية')));return;}
    await db.update('products',{'qty':next},where:'id=?',whereArgs:[item['id']]);
    await db.insert('stock_moves',{'product_id':item['id'],'product_name':item['name'],'kind':kind,'qty':q,'created_at':DateTime.now().toIso8601String()});
    await load();
  }
  @override Widget build(BuildContext context)=>Column(children:[
    Padding(padding:const EdgeInsets.all(10),child:TextField(decoration:const InputDecoration(prefixIcon:Icon(Icons.search),hintText:'ابحث عن منتج...'),onChanged:(v){query=v;load();})),
    Expanded(child:items.isEmpty?const EmptyHint('لا توجد منتجات. اضغط + لإضافة أول منتج.'):ListView.builder(itemCount:items.length,itemBuilder:(ctx,i){
      final e=items[i];final q=(e['qty'] as num).toDouble();final low=q<=(e['alert_qty'] as num).toDouble();
      return Card(child:ListTile(leading:CircleAvatar(backgroundColor:low?Colors.red.shade50:cream,child:Icon(Icons.spa,color:low?Colors.red:gold)),
        title:Text('${e['name']}',style:const TextStyle(fontWeight:FontWeight.bold)),
        subtitle:Text('${e['type']} • شراء ${egp((e['buy'] as num).toDouble())} • بيع ${egp((e['sell'] as num).toDouble())}\nالمخزون: $q ${e['unit']}'),
        isThreeLine:true,trailing:PopupMenuButton<String>(onSelected:(v){if(v=='edit')edit(e);if(v=='stock')stock(e);if(v=='delete')_delete(e);},itemBuilder:(_)=>const [PopupMenuItem(value:'stock',child:Text('حركة مخزون')),PopupMenuItem(value:'edit',child:Text('تعديل')),PopupMenuItem(value:'delete',child:Text('حذف'))]))); })),
    FloatingActionButton.extended(onPressed:()=>edit(),icon:const Icon(Icons.add),label:const Text('إضافة منتج'))
  ]);
  Future<void> _delete(Map<String,Object?> e) async {
    final yes=await showDialog<bool>(context:context,builder:(c)=>AlertDialog(title:const Text('تأكيد الحذف'),content:Text('حذف ${e['name']}؟'),actions:[TextButton(onPressed:()=>Navigator.pop(c,false),child:const Text('إلغاء')),FilledButton(onPressed:()=>Navigator.pop(c,true),child:const Text('حذف'))]));
    if(yes==true){await (await AppDb.instance.database).delete('products',where:'id=?',whereArgs:[e['id']]);await load();}
  }
}

Widget _field(TextEditingController c,String label,{bool num=false})=>Padding(padding:const EdgeInsets.symmetric(vertical:5),child:TextField(controller:c,keyboardType:num?const TextInputType.numberWithOptions(decimal:true):TextInputType.text,decoration:InputDecoration(labelText:label)));

class SalesPage extends StatefulWidget {const SalesPage({super.key});@override State<SalesPage> createState()=>_SalesPageState();}
class _SalesPageState extends State<SalesPage>{
  List<Map<String,Object?>> sales=[];
  @override void initState(){super.initState();load();}
  Future<void> load()async{final x=await AppDb.instance.rows('sales');if(mounted)setState(()=>sales=x);}
  Future<void> addSale()async{
    final db=await AppDb.instance.database;final products=await db.query('products',where:'qty > 0',orderBy:'name');
    if(products.isEmpty){ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('أضف منتجات للمخزون أولًا')));return;}
    int? selected=(products.first['id'] as int);final qty=TextEditingController(text:'1'),price=TextEditingController(text:'${products.first['sell']}'),customer=TextEditingController(),paid=TextEditingController();
    double discount=0;String payment='كاش';
    final ok=await showDialog<bool>(context:context,builder:(ctx)=>StatefulBuilder(builder:(ctx,setD){
      final product=products.firstWhere((e)=>e['id']==selected);
      return AlertDialog(title:const Text('فاتورة بيع جديدة'),content:SizedBox(width:400,child:SingleChildScrollView(child:Column(mainAxisSize:MainAxisSize.min,children:[
        DropdownButtonFormField<int>(value:selected,decoration:const InputDecoration(labelText:'المنتج'),items:products.map((e)=>DropdownMenuItem(value:e['id'] as int,child:Text('${e['name']} (متاح ${e['qty']})'))).toList(),onChanged:(v){setD(()=>selected=v);price.text='${products.firstWhere((e)=>e['id']==v)['sell']}';}),
        _field(customer,'اسم العميل'),_field(qty,'الكمية',num:true),_field(price,'سعر الوحدة',num:true),_field(paid,'المبلغ المدفوع',num:true),
        DropdownButtonFormField<String>(value:payment,decoration:const InputDecoration(labelText:'طريقة الدفع'),items:['كاش','فودافون كاش','إنستا باي','تحويل بنكي','آجل'].map((e)=>DropdownMenuItem(value:e,child:Text(e))).toList(),onChanged:(v)=>setD(()=>payment=v!)),
        Text('المتاح: ${product['qty']} ${product['unit']} • التكلفة: ${egp((product['buy'] as num).toDouble())}',style:const TextStyle(fontSize:12))
      ]))),actions:[TextButton(onPressed:()=>Navigator.pop(ctx,false),child:const Text('إلغاء')),FilledButton(onPressed:()=>Navigator.pop(ctx,true),child:const Text('حفظ الفاتورة'))]);
    }));
    if(ok!=true)return;
    final product=products.firstWhere((e)=>e['id']==selected);final q=numVal(qty.text),unitPrice=numVal(price.text),paidVal=numVal(paid.text),available=(product['qty'] as num).toDouble();
    if(q<=0||q>available||unitPrice<0){ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('راجع الكمية والسعر')));return;}
    final total=max(0,q*unitPrice-discount);final now=DateTime.now().toIso8601String();
    final count=Sqflite.firstIntValue(await db.rawQuery('SELECT COUNT(*) FROM sales'))??0;
    final no='INV-${DateTime.now().year}-${(count+1).toString().padLeft(5,'0')}';
    await db.transaction((txn)async{
      await txn.insert('sales',{'invoice_no':no,'customer':customer.text,'product_id':selected,'product_name':product['name'],'qty':q,'unit_price':unitPrice,'unit_cost':product['buy'],'discount':discount,'total':total,'paid':paidVal,'payment':payment,'status':paidVal>=total?'مدفوعة':paidVal>0?'مدفوعة جزئيًا':'آجلة','created_at':now});
      await txn.update('products',{'qty':available-q},where:'id=?',whereArgs:[selected]);
      await txn.insert('stock_moves',{'product_id':selected,'product_name':product['name'],'kind':'بيع','qty':q,'note':no,'created_at':now});
    });
    await load();
  }
  @override Widget build(BuildContext context)=>Column(children:[
    Expanded(child:sales.isEmpty?const EmptyHint('لا توجد فواتير'):ListView.builder(itemCount:sales.length,itemBuilder:(c,i){final e=sales[i];return Card(child:ListTile(leading:const Icon(Icons.receipt,color:gold),title:Text('${e['invoice_no']} • ${e['product_name']}'),subtitle:Text('${e['customer']??'عميل نقدي'} • ${e['created_at']}\\n${e['status']} - ${e['payment']}'),isThreeLine:true,trailing:Text(egp((e['total'] as num).toDouble()))));})),
    Padding(padding:const EdgeInsets.all(10),child:FilledButton.icon(onPressed:addSale,icon:const Icon(Icons.add),label:const Text('إنشاء فاتورة')))
  ]);
}

class ExpensesPage extends StatefulWidget{const ExpensesPage({super.key});@override State<ExpensesPage> createState()=>_ExpensesPageState();}
class _ExpensesPageState extends State<ExpensesPage>{
 List<Map<String,Object?>> items=[];
 @override void initState(){super.initState();load();}
 Future<void> load()async{final x=await AppDb.instance.rows('expenses');if(mounted)setState(()=>items=x);}
 Future<void> add()async{
  final amount=TextEditingController(),note=TextEditingController();String cat='مصاريف أخرى',pay='كاش';
  final cats=['إيجار','كهرباء','مياه','إنترنت','نقل','رواتب','تغليف','إعلانات','صيانة','ضرائب','مصاريف أخرى'];
  final ok=await showDialog<bool>(context:context,builder:(c)=>StatefulBuilder(builder:(c,setD)=>AlertDialog(title:const Text('إضافة مصروف'),content:Column(mainAxisSize:MainAxisSize.min,children:[
   DropdownButtonFormField(value:cat,items:cats.map((e)=>DropdownMenuItem(value:e,child:Text(e))).toList(),onChanged:(v)=>setD(()=>cat=v!)),
   _field(amount,'المبلغ',num:true),_field(note,'ملاحظات'),
   DropdownButtonFormField(value:pay,items:['كاش','فودافون كاش','إنستا باي','تحويل بنكي'].map((e)=>DropdownMenuItem(value:e,child:Text(e))).toList(),onChanged:(v)=>setD(()=>pay=v!))
  ]),actions:[TextButton(onPressed:()=>Navigator.pop(c,false),child:const Text('إلغاء')),FilledButton(onPressed:()=>Navigator.pop(c,true),child:const Text('حفظ'))])));
  if(ok==true&&numVal(amount.text)>0){await AppDb.instance.add('expenses',{'category':cat,'amount':numVal(amount.text),'payment':pay,'note':note.text,'created_at':DateTime.now().toIso8601String()});await load();}
 }
 @override Widget build(BuildContext context)=>Column(children:[
  Expanded(child:items.isEmpty?const EmptyHint('لا توجد مصروفات'):ListView(children:items.map((e)=>Card(child:ListTile(leading:const Icon(Icons.payments,color:gold),title:Text('${e['category']}'),subtitle:Text('${e['created_at']} • ${e['payment']}'),trailing:Text(egp((e['amount'] as num).toDouble())))).toList())),
  Padding(padding:const EdgeInsets.all(10),child:FilledButton.icon(onPressed:add,icon:const Icon(Icons.add),label:const Text('إضافة مصروف')))
 ]);
}

class ToolsPage extends StatelessWidget{
 const ToolsPage({super.key});
 @override Widget build(BuildContext context)=>ListView(padding:const EdgeInsets.all(12),children:[
  _tool(context,'حاسبة تكلفة العطر','احسب تكلفة العبوة وسعر البيع والربح',Icons.calculate, const CostCalc()),
  _tool(context,'حاسبة نسب الخلط','احسب الزيت والكحول والماء حسب النسب',Icons.science,const MixCalc()),
  _tool(context,'تصدير CSV','تصدير المنتجات والمبيعات والمصاريف',Icons.table_chart,const ExportPage()),
  _tool(context,'النسخ الاحتياطي','حفظ نسخة من قاعدة البيانات واستعادتها',Icons.backup,const BackupPage()),
  _tool(context,'تقارير الأرباح','ملخص المبيعات والتكلفة والمصاريف',Icons.analytics,const ReportsPage()),
  _tool(context,'حركة المخزون','عرض سجل الإضافة والبيع والتالف',Icons.swap_vert,const StockLogPage()),
 ]);
}
Widget _tool(BuildContext c,String title,String sub,IconData icon,Widget page)=>Card(child:ListTile(leading:CircleAvatar(backgroundColor:gold.withOpacity(.2),child:Icon(icon,color:dark)),title:Text(title,style:const TextStyle(fontWeight:FontWeight.bold)),subtitle:Text(sub),trailing:const Icon(Icons.chevron_left),onTap:()=>Navigator.push(c,MaterialPageRoute(builder:(_)=>page))));

class CostCalc extends StatefulWidget{const CostCalc({super.key});@override State<CostCalc> createState()=>_CostCalcState();}
class _CostCalcState extends State<CostCalc>{
 final oil=TextEditingController(),alcohol=TextEditingController(),bottle=TextEditingController(),pack=TextEditingController(),extra=TextEditingController(),margin=TextEditingController(text:'50');
 double cost=0,sell=0;
 void calc(){setState((){cost=numVal(oil.text)+numVal(alcohol.text)+numVal(bottle.text)+numVal(pack.text)+numVal(extra.text);sell=cost*(1+numVal(margin.text)/100);});}
 @override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:const Text('حاسبة تكلفة العطر')),body:ListView(padding:const EdgeInsets.all(16),children:[
  _field(oil,'تكلفة الزيت (جنيه)'),_field(alcohol,'تكلفة الكحول / القاعدة'),_field(bottle,'العبوة والغطاء'),_field(pack,'الملصق والتغليف'),_field(extra,'شحن ومصاريف وعمالة'),_field(margin,'نسبة الربح %'),
  FilledButton(onPressed:calc,child:const Text('احسب التكلفة والسعر')),
  Card(child:Padding(padding:const EdgeInsets.all(18),child:Column(children:[Text('التكلفة: ${egp(cost)}'),Text('سعر البيع المقترح: ${egp(sell)}',style:const TextStyle(fontSize:20,fontWeight:FontWeight.bold)),Text('الربح المتوقع: ${egp(sell-cost)}')]))),
  const Text('ملاحظة: نسبة الربح هنا زيادة على التكلفة (Markup)، وليست هامش ربح من سعر البيع.')
 ]));
}

class MixCalc extends StatefulWidget{const MixCalc({super.key});@override State<MixCalc> createState()=>_MixCalcState();}
class _MixCalcState extends State<MixCalc>{
 final total=TextEditingController(text:'1000'),oil=TextEditingController(text:'20'),alc=TextEditingController(text:'75'),water=TextEditingController(text:'5');
 @override Widget build(BuildContext context){final t=numVal(total.text),a=numVal(oil.text),b=numVal(alc.text),c=numVal(water.text),sum=a+b+c;
 return Scaffold(appBar:AppBar(title:const Text('حاسبة نسب الخلط')),body:ListView(padding:const EdgeInsets.all(16),children:[
 _field(total,'حجم التشغيلة (مل أو جرام)'),_field(oil,'نسبة الزيت %',num:true),_field(alc,'نسبة الكحول %',num:true),_field(water,'نسبة الماء %',num:true),
 Card(child:Padding(padding:const EdgeInsets.all(16),child:Column(children:[
 Text('مجموع النسب: ${money.format(sum)}%'),
 Text('الزيت: ${money.format(t*a/100)}'),Text('الكحول: ${money.format(t*b/100)}'),Text('الماء: ${money.format(t*c/100)}'),
 Text(sum==100?'النسب صحيحة':'يجب أن يكون مجموع النسب 100%',style:TextStyle(color:sum==100?Colors.green:Colors.red,fontWeight:FontWeight.bold))
 ]))),
 const Text('الحساب يفترض أن جميع المكونات مقاسة بنفس الوحدة. التحويل بين الجرام والمل يحتاج معرفة كثافة المادة.')
 ]));}
}

class ReportsPage extends StatefulWidget{const ReportsPage({super.key});@override State<ReportsPage> createState()=>_ReportsPageState();}
class _ReportsPageState extends State<ReportsPage>{
 double sales=0,cost=0,expenses=0;int count=0;
 @override void initState(){super.initState();load();}
 Future<void> load()async{final db=await AppDb.instance.database;
 final s=await db.rawQuery('SELECT COALESCE(SUM(total),0) v, COUNT(*) c FROM sales');
 final co=await db.rawQuery('SELECT COALESCE(SUM(qty*unit_cost),0) v FROM sales');
 final ex=await db.rawQuery('SELECT COALESCE(SUM(amount),0) v FROM expenses');
 setState((){sales=(s.first['v'] as num).toDouble();count=(s.first['c'] as int);cost=(co.first['v'] as num).toDouble();expenses=(ex.first['v'] as num).toDouble();});
 }
 @override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:const Text('تقارير الأرباح')),body:ListView(padding:const EdgeInsets.all(16),children:[
  tileReport('إجمالي المبيعات',sales),tileReport('تكلفة البضاعة المباعة',cost),tileReport('إجمالي المصروفات',expenses),tileReport('مجمل الربح',sales-cost),tileReport('صافي الربح',sales-cost-expenses),
  ListTile(title:const Text('عدد الفواتير'),trailing:Text('$count'))
 ]));
 Widget tileReport(String s,double v)=>Card(child:ListTile(title:Text(s),trailing:Text(egp(v),style:const TextStyle(fontWeight:FontWeight.bold))));
}

class StockLogPage extends StatefulWidget{const StockLogPage({super.key});@override State<StockLogPage> createState()=>_StockLogPageState();}
class _StockLogPageState extends State<StockLogPage>{
 List<Map<String,Object?>> data=[];
 @override void initState(){super.initState();AppDb.instance.rows('stock_moves').then((v){if(mounted)setState(()=>data=v);});}
 @override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:const Text('حركة المخزون')),body:data.isEmpty?const EmptyHint('لا توجد حركات'):ListView(children:data.map((e)=>ListTile(leading:const Icon(Icons.swap_horiz),title:Text('${e['product_name']} • ${e['kind']}'),subtitle:Text('${e['created_at']} ${e['note']??''}'),trailing:Text('${e['qty']}'))).toList()));
}

class ExportPage extends StatelessWidget{
 const ExportPage({super.key});
 Future<void> export(BuildContext context,String table)async{
  final rows=await AppDb.instance.rows(table);
  if(rows.isEmpty){ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('لا توجد بيانات للتصدير')));return;}
  final headers=rows.first.keys.toList();
  final data=<List<dynamic>>[headers,...rows.map((r)=>headers.map((h)=>r[h]).toList())];
  final csv=const ListToCsvConverter().convert(data);
  final bytes=Uint8List.fromList([0xEF,0xBB,0xBF,...utf8.encode(csv)]);
  await Share.shareXFiles([XFile.fromData(bytes,mimeType:'text/csv',name:'$table.csv')],text:'تصدير بيانات $table');
 }
 @override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:const Text('تصدير البيانات')),body:ListView(padding:const EdgeInsets.all(12),children:[
  for(final t in ['products','sales','expenses','customers','suppliers','purchases','stock_moves'])
   Card(child:ListTile(title:Text(t),subtitle:const Text('ملف CSV يفتح في Excel'),trailing:const Icon(Icons.share),onTap:()=>export(context,t)))
 ]));
}

class BackupPage extends StatelessWidget{
 const BackupPage({super.key});
 Future<void> backup(BuildContext context)async{
  final db=await AppDb.instance.database;final names=['products','sales','expenses','stock_moves','customers','suppliers','purchases','settings'];
  final data=<String,dynamic>{'app':'perfume_manager','version':1,'created_at':DateTime.now().toIso8601String()};
  for(final n in names)data[n]=await db.query(n);
  final bytes=Uint8List.fromList(utf8.encode(const JsonEncoder.withIndent('  ').convert(data)));
  await Share.shareXFiles([XFile.fromData(bytes,mimeType:'application/json',name:'perfume_backup.json')],text:'نسخة احتياطية لإدارة عطور');
 }
 Future<void> restore(BuildContext context)async{
  final result=await FilePicker.platform.pickFiles(type:FileType.custom,allowedExtensions:['json'],withData:true);
  if(result==null||result.files.single.bytes==null)return;
  final yes=await showDialog<bool>(context:context,builder:(c)=>AlertDialog(title:const Text('تأكيد الاستعادة'),content:const Text('سيتم استبدال البيانات الحالية بمحتوى النسخة الاحتياطية. هل تريد المتابعة؟'),actions:[TextButton(onPressed:()=>Navigator.pop(c,false),child:const Text('إلغاء')),FilledButton(onPressed:()=>Navigator.pop(c,true),child:const Text('استعادة'))]));
  if(yes!=true)return;
  try{
   final obj=jsonDecode(utf8.decode(result.files.single.bytes!)) as Map<String,dynamic>;
   if(obj['app']!='perfume_manager')throw Exception('ملف غير صالح');
   final db=await AppDb.instance.database;final names=['products','sales','expenses','stock_moves','customers','suppliers','purchases','settings'];
   await db.transaction((txn)async{for(final n in names){await txn.delete(n);for(final row in (obj[n] as List? ?? [])){await txn.insert(n,Map<String,Object?>.from(row as Map));}}});
   if(context.mounted)ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('تمت الاستعادة بنجاح')));
  }catch(e){if(context.mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('تعذر الاستعادة: $e')));}
 }
 @override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:const Text('النسخ الاحتياطي')),body:Padding(padding:const EdgeInsets.all(16),child:Column(children:[
  const Icon(Icons.cloud_done_outlined,size:64,color:gold),const Text('بياناتك محفوظة محليًا على الهاتف. احتفظ بنسخة احتياطية في مكان آمن.'),
  const SizedBox(height:20),FilledButton.icon(onPressed:()=>backup(context),icon:const Icon(Icons.upload),label:const Text('إنشاء ومشاركة نسخة احتياطية')),
  OutlinedButton.icon(onPressed:()=>restore(context),icon:const Icon(Icons.download),label:const Text('استعادة نسخة احتياطية'))
 ])));
}

class SettingsPage extends StatefulWidget{const SettingsPage({super.key});@override State<SettingsPage> createState()=>_SettingsPageState();}
class _SettingsPageState extends State<SettingsPage>{
 final shop=TextEditingController(),phone=TextEditingController(),address=TextEditingController();
 @override void initState(){super.initState();load();}
 Future<void> load()async{final db=await AppDb.instance.database;final x=await db.query('settings');for(final e in x){if(e['key']=='shop')shop.text='${e['value']}';if(e['key']=='phone')phone.text='${e['value']}';if(e['key']=='address')address.text='${e['value']}';}if(mounted)setState((){});}
 Future<void> save()async{final db=await AppDb.instance.database;for(final e in {'shop':shop.text,'phone':phone.text,'address':address.text}.entries){await db.insert('settings',{'key':e.key,'value':e.value},conflictAlgorithm:ConflictAlgorithm.replace);}if(mounted)ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('تم حفظ الإعدادات')));}
 Future<void> changePin()async{final c=TextEditingController();final ok=await showDialog<bool>(context:context,builder:(ctx)=>AlertDialog(title:const Text('تغيير الرقم السري'),content:TextField(controller:c,obscureText:true,keyboardType:TextInputType.number,decoration:const InputDecoration(labelText:'الرقم السري الجديد')),actions:[TextButton(onPressed:()=>Navigator.pop(ctx,false),child:const Text('إلغاء')),FilledButton(onPressed:()=>Navigator.pop(ctx,true),child:const Text('حفظ'))]));if(ok==true&&c.text.length>=4){final p=await SharedPreferences.getInstance();await p.setString('pin',c.text);}}
 @override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:const Text('الإعدادات')),body:ListView(padding:const EdgeInsets.all(16),children:[
 _field(shop,'اسم المحل'),_field(phone,'رقم الهاتف'),_field(address,'العنوان'),
 FilledButton(onPressed:save,child:const Text('حفظ بيانات المحل')),const SizedBox(height:10),
 OutlinedButton(onPressed:changePin,child:const Text('تغيير الرقم السري')),
 const Divider(),const ListTile(title:Text('عن التطبيق'),subtitle:Text('إدارة عطور - يعمل دون اتصال بالإنترنت، وتُحفظ البيانات محليًا على الهاتف.')),
 const ListTile(title:Text('سياسة الخصوصية'),subtitle:Text('لا يرسل التطبيق بياناتك إلى خوادم خارجية. أنت مسؤول عن حفظ النسخ الاحتياطية وحمايتها.'))
 ]));
}
